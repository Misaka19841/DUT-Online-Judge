#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int MOD=998244353;

void dfs(int i,vector<int> & x,int b,vector<ll> & bin)
{
	if(i==0) return ;
	int a=x[i],c=6-a-b;
	if(a==b) dfs(i-1,x,b,bin);
	else
	{
		dfs(i-1,x,c,bin);
		bin[0]++;
		bin[i-1]++,bin[0]--;
	}
	return ;
}

vector<ll> calc1(int & n,vector<int> & x,vector<int> & y)
{
	int a=x[n],b=y[n],c=6-a-b;
	vector<ll> bin(n+1,0);
	dfs(n-1,x,c,bin);
	bin[0]++;
	dfs(n-1,y,c,bin);
	return bin;
}

vector<ll> calc2(int & n,vector<int> & x,vector<int> & y)
{
	int a=x[n],b=y[n],c=6-a-b;
	vector<ll> bin(n+1,0);
	dfs(n-1,x,b,bin);
	bin[0]++;
	bin[n-1]++,bin[0]--;
	bin[0]++;
	dfs(n-1,y,a,bin);
	return bin;
}

bool cmp(vector<ll> bin1,vector<ll> bin2)
{
	for(int i=0;i+1<bin1.size();i++)
	{
		bin1[i+1]+=bin1[i]/2,bin2[i+1]+=bin2[i]/2;
		bin1[i]%=2,bin2[i]%=2;
	}
	for(int i=bin1.size()-1;i>=0;i--)
		if(bin1[i]!=bin2[i])
			return bin1[i]<bin2[i];
	return false;
}

ll bin2dec(vector<ll> bin)
{
	ll dec=0;
	for(int i=bin.size()-1;i>=0;i--) dec=(dec*2+bin[i])%MOD;
	return dec;
}

void solve()
{
	int n;
    cin>>n;
	vector<int> x(n+1,0),y(n+1,0);
    for(int i=1;i<=n;i++) cin>>x[i];
	for(int i=1;i<=n;i++) cin>>y[i];
	while(n>=1 && x[n]==y[n]) n--;
	if(n==0)
	{
		cout<<"0\n";
		return ;
	}
	vector<ll> bin1=calc1(n,x,y);
	vector<ll> bin2=calc2(n,x,y);
	vector<ll> bin=min(bin1,bin2,cmp);
	cout<<bin2dec(bin)<<'\n';
    return ;
}

int main()
{
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int T;
    cin>>T;
    while(T--) solve();
    return 0;
}