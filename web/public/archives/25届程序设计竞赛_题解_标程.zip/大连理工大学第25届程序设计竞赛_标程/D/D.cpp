#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=1e5+10;
int n,m;
vector<int> e[N];
struct Edge
{
    int u,v;
};
vector<Edge> tr;
int fa[N];
int p[N];

int find(int u)
{
    return u==p[u] ? p[u] : p[u]=find(p[u]);
}

void dfs(int u)
{
    for(int v : e[u])
    {
        if(v==fa[u]) continue;
        fa[v]=u;
        dfs(v);
    }
    return ;
}

void first_run()
{
    cin>>n>>m;
    tr.clear();
    for(int u=1;u<=n;u++) p[u]=u,e[u].clear();
    for(int i=1,u,v;i<=m;i++)
    {
        cin>>u>>v;
        if(find(u)==find(v)) continue;
        p[find(u)]=find(v);
        e[u].push_back(v),e[v].push_back(u);
        tr.push_back({u,v});
    }
    fa[tr[0].u]=0;
    dfs(tr[0].u);
    for(int i=1;i<=n-2;i++) cout<<(fa[tr[i].u]==tr[i].v);
    cout<<"00\n";   //输出的01串要求长度恰好为n
    return ;
}

void second_run()
{
    cin>>n>>m;
    for(int u=1;u<=n;u++) p[u]=u;
    int si=0;
    string str;
    cin>>str;
    str="0"+str;
    for(int i=1,u,v;i<=m;i++)
    {
        cin>>u>>v;
        if(find(u)==find(v))
        {
            cout<<"0"<<endl;
            cout.flush();
            continue;
        }
        p[find(u)]=find(v);
        cout<<str[si++]<<endl;
        cout.flush();
    }
    return ;
}

int main()
{
    string str;
    cin>>str;
    int T;
    cin>>T;
    while(T--)
    {
        if(str=="first") first_run();
        else second_run();
    }
    return 0;
}