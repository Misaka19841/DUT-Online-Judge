#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=1e5+10;
int n,m;
vector<int> e[N];
int c[N];

void dfs(int u)
{
    for(int v : e[u])
    {
        if(c[v]!=-1) continue;
        if(u<v) c[v]=c[u];
        else c[v]=c[u]^1;
        dfs(v);
    }
    return ;
}

void first_run()
{
    cin>>n>>m;
    for(int u=1;u<=n;u++) c[u]=-1,e[u].clear();
    for(int i=1,u,v;i<=m;i++)
    {
        cin>>u>>v;
        e[u].push_back(v),e[v].push_back(u);
    }
    c[1]=0;
    dfs(1);
    for(int i=2;i<=n;i++) cout<<c[i];
    cout<<"0\n";
    return ;
}

void second_run()
{
    cin>>n>>m;
    string str;
    cin>>str;
    for(int u=2;u<=n;u++) c[u]=str[u-2]-'0';
    for(int i=1,u,v;i<=m;i++)
    {
        cin>>u>>v;
        cout<<((c[u]!=c[v])^(u>v))<<endl;
        cout.flush();
    }
    return ;
}

int main()
{
    string str;
    cin>>str;
    int T;
    cin>>T;
    while(T--)
    {
        if(str=="first") first_run();
        else second_run();
    }
    return 0;
}