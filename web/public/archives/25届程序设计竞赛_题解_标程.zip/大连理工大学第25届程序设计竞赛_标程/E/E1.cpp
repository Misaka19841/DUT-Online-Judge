#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll lowbit(ll x){
    return x&-x;
}
int main(){
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    ll T=1;
    cin>>T;
    while(T--){
        ll l,r;
        cin>>l>>r;
        while(r>=l)r-=lowbit(r);
        if(r==l-1)cout<<"Yes\n";
        else cout<<"No\n";
    }
    return 0;
}