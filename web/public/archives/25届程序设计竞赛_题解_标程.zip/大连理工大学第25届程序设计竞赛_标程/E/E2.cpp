#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll lowbit(ll x){
    return x&-x;
}
int main(){
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    ll T=1;
    cin>>T;
    while(T--){
        ll l,r;
        cin>>l>>r;
        if((l&1)==0) cout<<"No\n";
        else if(l==1) cout<<"Yes\n";
        else if(r<(l-1)+lowbit(l-1)) cout<<"Yes\n";
        else cout<<"No\n";
    }
}