    unordered_map<long long, int> cnt;
    for (int i = 0; i < n; ++i) {
        long long a;
        cin >> a;
        long long p = a / n + 1; 
        
        // 周期大于 1e8 的草对于后续询问毫无意义
        if (p <= 100000000) {
            cnt[p]++;
        }
    }

    // 离线处理询问
    while (m--) {
        long long k;
        cin >> k;

        // 特判第一圈
        if (k == 1) {
            cout << n << "\n";
            continue;
        }

        long long target = k - 1;
        long long ans = 0;
        
        // O(sqrt(k)) 枚举约数
        for (long long d = 1; d * d <= target; ++d) {
            if (target % d == 0) {
                // 如果 d 是 target 的约数，加上周期为 d 的杂草数
                if (cnt.count(d)) {
                    ans += cnt[d];
                }
                
                // 别忘了加上另一个约数 target/d（注意完全平方数重复计算）
                long long d2 = target / d;
                if (d2 != d) {
                    if (cnt.count(d2)) {
                        ans += cnt[d2];
                    }
                }
            }
        }
        cout << ans << "\n";
    }