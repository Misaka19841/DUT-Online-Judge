void solve() {
    ll L, W, H, dx, dy, dz;
    cin >> L >> W >> H >> dx >> dy >> dz;

    // 1. 算比例分子 (最大 10^18，刚好不爆 long long)
    ll A = dx * W * H;
    ll B = dy * L * H;
    ll C = dz * L * W;

    // 2. 求 GCD 约分
    ll g = std::gcd(A, std::gcd(B, C));
    ll a = A / g, b = B / g, c = C / g;

    // 3. 奇偶判落点 (奇数翻到对面，偶数滚回起点)
    ll x = (a % 2) ? L : 0;
    ll y = (b % 2) ? W : 0;
    ll z = (c % 2) ? H : 0;

    // 4. 输出
    cout << x << " " << y << " " << z << "\n";
    cout << a - 1 << " " << b - 1 << " " << c - 1 << "\n";
}