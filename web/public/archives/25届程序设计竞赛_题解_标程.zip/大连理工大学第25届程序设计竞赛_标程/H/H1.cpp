#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    string s, ans;
    cin >> s;

    for (int i = 0; i < (int)s.size(); ) {
        if (i + 6 < (int)s.size() && s.substr(i, 7) == "nailong") {
            ans += "shenmeya";
            i += 7;
        } else {
            ans += s[i];
            i++;
        }
    }

    cout << ans << '\n';
    return 0;
}