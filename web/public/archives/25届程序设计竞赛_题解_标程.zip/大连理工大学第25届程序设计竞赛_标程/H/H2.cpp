#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    string s;
    cin >> s;
    for (int i = 0; i + 6 < s.size(); i++)
    {
        string t = s.substr(i, 7);
        if (t == "nailong")
        {
            string u = s.substr(0, i);
            string v = s.substr(i + 7);
            s = u + "shenmeya" + v;
        }
    }
    cout << s << endl;
    return 0;
}