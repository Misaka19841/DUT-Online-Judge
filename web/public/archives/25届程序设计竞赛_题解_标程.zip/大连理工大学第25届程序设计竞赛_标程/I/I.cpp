#include<bits/stdc++.h>
#define maxn 5010
using namespace std;
int read()
{
	bool f=0; int x=0; char ch=getchar();
	while(ch<'0'||ch>'9') f|=ch=='-',ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
	return f?-x:x;
}
void write(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>9) write(x/10); putchar(x%10|'0');
}
int n,m,turn,sum;
struct player
{
	// 0:炸弹 1:拆除 2:跳过 3:抽底 4:透视
	int card[5];
	bool out;
	unordered_set<int> known;
}p[maxn];
struct card
{
	int id,type;
	bool known;
};
deque<card> q;
char s[11];
#define know_top(turn) (q.front().known||p[turn].known.find(q.front().id)!=p[turn].known.end())
#define know_bottom(turn) (q.back().known||p[turn].known.find(q.back().id)!=p[turn].known.end())
void draw(int turn,bool top)// 抽牌 0:顶部 1:底部
{
	assert(!q.empty()); card c;
	if(!top) c=q.front(),q.pop_front();
	else c=q.back(),q.pop_back(),printf("Player %d used Fetch\n",turn),p[turn].card[3]--;
	if(c.type) { p[turn].card[c.type]++; return; }
	if(!p[turn].card[1]) { printf("Player %d out\n",turn); p[turn].out=1; sum--; return; }
	printf("Player %d used Defuse\n",turn); p[turn].card[1]--;
	c.known=1; q.push_front(c);
}
void skip(int turn)// 跳过
{
	printf("Player %d used Skip\n",turn); p[turn].card[2]--;
}
void peek(int turn)// 透视
{
	printf("Player %d used Peek\n",turn); p[turn].card[4]--;
	if(q.size()<=3) for(auto c:q) p[turn].known.insert(c.id);
	else
	{
		for(int i=0;i<=2;i++) p[turn].known.insert(q[i].id);
		p[turn].known.insert(q.back().id);
	}
}
bool round1(int turn)
{
	if(know_top(turn))
	{
		if(q.front().type) { draw(turn,0); return 1; }
		if(know_bottom(turn))
		{
			if(q.back().type&&p[turn].card[3]) draw(turn,1);
			else if(p[turn].card[2]) skip(turn);
			else draw(turn,0);
			return 1;
		}
	}
	else if(know_bottom(turn)&&q.back().type&&p[turn].card[3]) { draw(turn,1); return 1; }
	return 0;
}
int main()
{
	n=read(); m=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=5;j++)
		{
			scanf("%s",s);
			if(s[0]=='D') p[i].card[1]++;
			else if(s[0]=='S') p[i].card[2]++;
			else if(s[0]=='F') p[i].card[3]++;
			else p[i].card[4]++;
		}
	for(int i=1,type;i<=m;i++)
	{
		scanf("%s",s);
		if(s[0]=='B') type=0;
		else if(s[0]=='D') type=1; else if(s[0]=='S') type=2;
		else if(s[0]=='F') type=3; else type=4;
		q.push_back((card){ i,type,0 });
	}
	sum=n;
	while(sum>1)
	{
		do { turn++; if(turn>n) turn=1; } while(p[turn].out);
		if(round1(turn)) continue;
		if(p[turn].card[4]) { peek(turn); assert(round1(turn)); continue; }
		if(p[turn].card[2]) { skip(turn); continue; }
		if(know_bottom(turn)&&!q.back().type) { draw(turn,0); continue; }
		if(p[turn].card[3]) draw(turn,1);
		else draw(turn,0);
	}
	for(int i=1;i<=n;i++) if(!p[i].out) { printf("Player %d win\n",i); break; }
	return 0;
}