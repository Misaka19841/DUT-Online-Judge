#include "testlib.h"
#include <iostream>
using namespace std;
int main(int argc, char *argv[]) {
    registerTestlibCmd(argc, argv);
    
}